import { getAllProducts, searchProducts } from "./products.js";
import {
  addToCart,
  removeFromCart,
  increaseQty,
  decreaseQty,
  clearCart,
  isInCart,
  getCartItems,
  getCartCount,
  getCartTotal,
  loadFromLocalStorage,
} from "./cart.js";

const productGrid   = document.getElementById("productGrid");
const cartBody      = document.getElementById("cartBody");
const cartFooter    = document.getElementById("cartFooter");
const cartTotal     = document.getElementById("cartTotal");
const cartBadge     = document.getElementById("cartBadge");
const emptyMsg      = document.getElementById("emptyMsg");
const clearCartBtn  = document.getElementById("clearCartBtn");
const checkoutBtn   = document.getElementById("checkoutBtn");
const cartToggle    = document.getElementById("cartToggle");
const closeCart     = document.getElementById("closeCart");
const cartSidebar   = document.getElementById("cartSidebar");
const cartOverlay   = document.getElementById("cartOverlay");
const searchInput   = document.getElementById("searchInput");

loadFromLocalStorage();
renderProducts(getAllProducts());
renderCart();

function renderProducts(list) {
  productGrid.innerHTML = "";

  if (list.length === 0) {
    productGrid.innerHTML = `<p class="no-results">No products found.</p>`;
    return;
  }

  list.forEach((product) => {
    const inCart = isInCart(product.id);
    const card = document.createElement("div");
    card.className = "product-card";
    card.dataset.id = product.id;

    card.innerHTML = `
      <div class="product-emoji">${product.emoji}</div>
      <div class="product-info">
        <span class="product-category">${product.category}</span>
        <h3 class="product-name">${product.name}</h3>
        <p class="product-price">₱${product.price.toFixed(2)}</p>
      </div>
      <button 
        class="btn-add ${inCart ? "in-cart" : ""}" 
        data-id="${product.id}"
        ${inCart ? "disabled" : ""}
      >
        ${inCart ? "✔ Already in Cart" : "Add to Cart"}
      </button>
    `;

    productGrid.appendChild(card);
  });

  document.querySelectorAll(".btn-add:not([disabled])").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = parseInt(btn.dataset.id);
      const product = getAllProducts().find((p) => p.id === id);
      addToCart(product);
      renderProducts(getCurrentList());
      renderCart();
      openCart();
    });
  });
}

function renderCart() {
  const items = getCartItems();
  const count = getCartCount();
  const total = getCartTotal();

  cartBadge.textContent = count;
  cartBadge.style.display = count > 0 ? "inline-flex" : "none";

  if (items.length === 0) {
    emptyMsg.style.display = "block";
    cartFooter.style.display = "none";
    cartBody.innerHTML = `<p class="empty-cart-msg">Your cart is empty. 🛍️</p>`;
    return;
  }

  emptyMsg.style.display = "none";
  cartFooter.style.display = "flex";
  cartTotal.textContent = `₱${total.toFixed(2)}`;

  cartBody.innerHTML = "";
  items.forEach((item) => {
    const row = document.createElement("div");
    row.className = "cart-item";
    row.innerHTML = `
      <div class="cart-item-left">
        <span class="cart-item-emoji">${item.emoji}</span>
        <div class="cart-item-details">
          <span class="cart-item-name">${item.name}</span>
          <span class="cart-item-subtotal">₱${(item.price * item.quantity).toFixed(2)}</span>
        </div>
      </div>
      <div class="cart-item-right">
        <button class="qty-btn dec-btn" data-id="${item.id}">−</button>
        <span class="qty-display">${item.quantity}</span>
        <button class="qty-btn inc-btn" data-id="${item.id}">+</button>
        <button class="remove-btn" data-id="${item.id}">🗑</button>
      </div>
    `;
    cartBody.appendChild(row);
  });

  cartBody.querySelectorAll(".inc-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      increaseQty(parseInt(btn.dataset.id));
      renderCart();
      renderProducts(getCurrentList());
    });
  });

  cartBody.querySelectorAll(".dec-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      decreaseQty(parseInt(btn.dataset.id));
      renderCart();
      renderProducts(getCurrentList());
    });
  });

  cartBody.querySelectorAll(".remove-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      removeFromCart(parseInt(btn.dataset.id));
      renderCart();
      renderProducts(getCurrentList());
    });
  });
}

function openCart() {
  cartSidebar.classList.add("open");
  cartOverlay.classList.add("show");
}

function closeCartPanel() {
  cartSidebar.classList.remove("open");
  cartOverlay.classList.remove("show");
}

cartToggle.addEventListener("click", openCart);
closeCart.addEventListener("click", closeCartPanel);
cartOverlay.addEventListener("click", closeCartPanel);

clearCartBtn.addEventListener("click", () => {
  clearCart();
  renderCart();
  renderProducts(getCurrentList());
});

checkoutBtn.addEventListener("click", () => {
  alert("✅ Thank you for your purchase! (Demo checkout)");
  clearCart();
  renderCart();
  renderProducts(getCurrentList());
  closeCartPanel();
});

let searchQuery = "";

searchInput.addEventListener("input", (e) => {
  searchQuery = e.target.value.trim();
  renderProducts(getCurrentList());
});

function getCurrentList() {
  return searchQuery ? searchProducts(searchQuery) : getAllProducts();
}
