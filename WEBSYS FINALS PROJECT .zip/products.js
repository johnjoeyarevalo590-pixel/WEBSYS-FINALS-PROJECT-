const products = [
  {
    id: 1,
    name: "Wireless Headphones",
    price: 599.00,
    emoji: "🎧",
    category: "Electronics",
  },
  {
    id: 2,
    name: "Mechanical Keyboard",
    price: 1499.00,
    emoji: "⌨️",
    category: "Electronics",
  },
  {
    id: 3,
    name: "Running Sneakers",
    price: 4299.00,
    emoji: "👟",
    category: "Fashion",
  },
  {
    id: 4,
    name: "Leather Backpack",
    price: 1900.00,
    emoji: "🎒",
    category: "Fashion",
  },
  {
    id: 5,
    name: "Stainless Water Bottle",
    price: 980.00,
    emoji: "🍶",
    category: "Lifestyle",
  },
  {
    id: 6,
    name: "Scented Candle Set",
    price: 400.00,
    emoji: "🕯️",
    category: "Lifestyle",
  },
];

export function getAllProducts() {
  return products;
}

export function getProductById(id) {
  return products.find((p) => p.id === id) || null;
}

export function searchProducts(query) {
  const q = query.toLowerCase();
  return products.filter((p) => p.name.toLowerCase().includes(q));
}
    price: 400.00,